<?php


?>

<!doctype html>
<html>
<head>
  <title>Lab 9</title>
</head>
<body>
<form action="install.php" method="get">
  <input type="submit" value="Install">
</form>
<form action="insert.php" method="get">
  <input type="submit" value="Insert">
</form>
<form action="final_output.php" method="get">
  <input type="submit" name ="Students" value="Students">
</form>
<form action="final_output.php" method="get">
  <input type="submit" name = "Grades" value="Grades">
</form>
</body>
</html>

