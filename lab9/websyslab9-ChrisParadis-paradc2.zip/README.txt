Lab 9
The most difficult part of this lab by far for me was the very beginning. My lack of experience with PHP led to an onslaught of syntax errors which proved very difficult to find as I was kindly greeted with a blank output every time I ran the program. I ended up needing to attend office hours in order to find these errors. The rest of the program consisted of trial and error and I had to rewrite programs multiple times. Also entering data into databases is a real pain which took much more time then I would have preferred it take. 

*Note*
 I submitted the file again after asking professor Plotka about the mysqli functions I included. After learning that they were not allowed I changed it all to PDO. 

*Note*
The latest submission fixed an error where I accidently called the wrong PHP file so it worked on my machine because it was present but not in the zip file I submitted. This should be the last version submitted. 
